"""
📝 VidderTech Logging System
Built by VidderTech - The Future of Quiz Bots
"""

from .vidder_logger import VidderLogger

__all__ = ['VidderLogger']